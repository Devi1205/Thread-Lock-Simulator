import streamlit as st

def section_header(title, icon=None):
    if icon:
        st.markdown(f"## {icon} {title}")
    else:
        st.markdown(f"## {title}")

def notify_success(msg):
    st.success(f"✅ {msg}")

def notify_info(msg):
    st.info(f"ℹ️ {msg}")

def notify_warning(msg):
    st.warning(f"⚠️ {msg}")
