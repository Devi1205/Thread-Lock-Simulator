import streamlit as st
from ui.utils import section_header

def show_timeline():
    section_header("📜 Execution Timeline")

    if not st.session_state.get("simulation_complete", False):
        st.warning("⚠️ Please run the simulation fully before viewing the timeline.")
        return

    timeline = st.session_state.get("timeline", [])
    if not timeline:
        st.warning("⚠️ No execution events recorded.")
        return

    st.subheader("🧵 Step-by-Step Execution")

    seen_blocks = set()
    step_count = 1  # Manually track step numbers (don’t skip numbers)

    for e in timeline:
        if e.action == "blocked":
            key = (e.thread, e.lock, e.held_by)
            if key in seen_blocks:
                continue  # Skip repeated blocked events
            seen_blocks.add(key)
            st.write(f"**{step_count}.** `{e.thread}` tries to acquire `{e.lock}` → ❌ **Blocked** (held by `{e.held_by}`)")
        elif e.action == "acquire":
            st.write(f"**{step_count}.** `{e.thread}` acquires `{e.lock}`")
        elif e.action == "release":
            st.write(f"**{step_count}.** `{e.thread}` releases `{e.lock}`")
        elif e.action == "access":
            st.write(f"**{step_count}.** `{e.thread}` accesses `{e.lock}`")
        step_count += 1  # Only increment for *displayed* steps
