import streamlit as st
import json
from ui.utils import section_header, notify_success, notify_info, notify_warning
from backend.thread_simulator import simulator

def show_simulator():
    section_header("Thread Lock Simulator", "🧵")

    st.session_state.setdefault("scenario_loaded", False)
    st.session_state.setdefault("timeline", [])
    st.session_state.setdefault("simulation_complete", False)

    # 1️⃣ Input selection
    input_mode = st.radio("Select Input Mode", ("📂 Upload JSON", "✍️ Manual Input"))

    if input_mode == "📂 Upload JSON":
        file = st.file_uploader("Upload Scenario JSON", type="json")
        if file and not st.session_state.scenario_loaded:
            try:
                scenario = json.load(file)
                simulator.load_scenario(scenario)
                simulator.reset()
                st.session_state.scenario_loaded = True
                st.session_state.timeline = []
                st.session_state.simulation_complete = False
                notify_success("Scenario loaded successfully!")
            except Exception as e:
                st.error(f"❌ Failed to load JSON: {e}")

    elif input_mode == "✍️ Manual Input":
        with st.form("manual_input_form"):
            num_threads = st.number_input("Number of Threads", 1, 5)
            lock_str = st.text_input("Lock Names (comma-separated)", "L1, L2")
            lock_names = [l.strip() for l in lock_str.split(",") if l.strip()]

            blocks = []
            for i in range(num_threads):
                name = st.text_input(f"Thread {i+1} Name", value=f"T{i+1}", key=f"name_{i}")
                inst = st.text_area(f"Instructions for {name}", key=f"inst_{i}")
                blocks.append((name, inst))

            submitted = st.form_submit_button("✅ Load Scenario")

        if submitted:
            try:
                scenario = {"locks": lock_names, "threads": []}
                for name, inst in blocks:
                    instrs = []
                    for line in inst.splitlines():
                        parts = line.strip().split()
                        if len(parts) == 2 and parts[0] in ("acquire", "release", "access"):
                            instrs.append(parts)
                    scenario["threads"].append({"name": name, "instructions": instrs})
                simulator.load_scenario(scenario)
                simulator.reset()
                st.session_state.scenario_loaded = True
                st.session_state.timeline = []
                st.session_state.simulation_complete = False
                notify_success("Manual scenario loaded!")
            except Exception as e:
                st.error(f"❌ Failed to load manual: {e}")

    # 2️⃣ Controls
    if st.session_state.scenario_loaded:
        st.markdown("---")
        c1, c2, c3 = st.columns(3)

        with c1:
            if st.button("▶ Step Execution"):
                if not simulator.has_more_steps():
                    notify_info("Simulation already reached end.")
                else:
                    progress = simulator.step()
                    st.session_state.timeline = simulator.timeline.copy()
                    st.session_state.simulation_complete = not simulator.has_more_steps()
                    if progress:
                        notify_info("✅ One step executed.")
                    else:
                        notify_warning("⚠️ No progress made. Threads may be blocked (possible deadlock).")

        with c2:
            if st.button("⏩ Run All Steps"):
                if not simulator.has_more_steps():
                    notify_info("Simulation already reached end.")
                else:
                    while simulator.has_more_steps():
                        progress = simulator.step()
                        if not progress:
                            notify_warning("🛑 Deadlock detected. No threads can proceed.")
                            break
                    st.session_state.timeline = simulator.timeline.copy()
                    st.session_state.simulation_complete = True
                    notify_success("✅ Simulation completed." if progress else "⚠️ Simulation halted due to blocking.")

        with c3:
            if st.button("🔄 Reset"):
                simulator.reset()
                st.session_state.scenario_loaded = False
                st.session_state.timeline = []
                st.session_state.simulation_complete = False
                notify_warning("Simulator reset.")

        st.markdown("### 📝 Thread Instructions")
        for t in simulator.threads:
            st.code(f"{t.name}: {t.instructions}")
    else:
        st.info("📥 Load a scenario to begin simulation.")
