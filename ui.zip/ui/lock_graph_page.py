import streamlit as st
import networkx as nx
import matplotlib.pyplot as plt
from backend.lock_graph import build_lock_graph, detect_deadlock
from ui.utils import section_header

def show_lock_graph():
    section_header("🔗 Lock Graph Viewer")

    if not st.session_state.get("simulation_complete", False):
        st.warning("⚠️ Please run the simulation fully before viewing the lock graph.")
        return

    timeline = st.session_state.get("timeline", [])
    if not timeline:
        st.warning("⚠️ No timeline data available.")
        return

    graph = build_lock_graph(timeline)
    cycle = detect_deadlock(graph)

    fig, ax = plt.subplots()
    pos = nx.spring_layout(graph)
    nx.draw(graph, pos, with_labels=True, arrows=True,
            node_color='skyblue', edge_color='gray', ax=ax)
    st.pyplot(fig)

    if cycle:
        st.error(f"🔴 Deadlock cycle detected: {cycle}")
    else:
        st.success("✅ No cycle detected in lock graph.")
