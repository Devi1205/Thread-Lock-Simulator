import streamlit as st
from collections import defaultdict
from backend.static_analyzer import static_deadlock_check
from backend.deadlock_predictor import predict_deadlock_from_live_state
from backend.race_checker import check_race_conditions
from backend.thread_simulator import simulator
from ui.utils import section_header

def explain_static_deadlock(scenario):
    deps     = defaultdict(set)
    patterns = []

    for th in scenario["threads"]:
        held = set()
        for act, lk in th["instructions"]:
            if act == "acquire":
                for h in held:
                    deps[h].add(lk)
                    patterns.append(f"- `{th['name']}` acquires `{h}` then `{lk}`")
                held.add(lk)
            else:
                held.discard(lk)

    cycles = []
    def dfs(u, path):
        if u in path:
            cycles.append(path[path.index(u):] + [u])
            return
        for v in deps.get(u, []):
            dfs(v, path + [u])

    for lk in deps:
        dfs(lk, [])

    if cycles:
        txt  = "⚠️ **Static deadlock detected!**\n\n"
        txt += "A cycle was found in the instruction order.\n\n"
        txt += "**Acquisition patterns:**\n" + "\n".join(patterns) + "\n\n"
        txt += "**Dependency cycle(s):**\n"
        for c in cycles:
            txt += " → ".join(f"`{x}`" for x in c) + "\n"
        return txt
    return "✅ No static deadlock detected."


def explain_live_deadlock(cycle):
    if not cycle:
        return "✅ No live deadlock detected at runtime."
    thr  = sorted({u for u, v, _ in cycle} | {v for u, v, _ in cycle})
    path = [cycle[0][0]] + [v for _, v, _ in cycle]
    return (
        "⚠️ **Live deadlock detected!**\n\n"
        f"Threads involved: {', '.join(thr)}\n\n"
        "**Wait-for cycle:**\n" + " → ".join(f"`{x}`" for x in path)
    )

def show_results():
    section_header("📊 Detection Results")

    if not st.session_state.get("timeline"):
        st.warning("⚠️ No simulation data—run all steps first.")
        return

    scenario = {
        "locks": list(simulator.locks.keys()),
        "threads": [{"name": t.name, "instructions": t.instructions}
                    for t in simulator.threads]
    }

    mode = st.session_state.get("mode", "Deadlock Detection")

    # Always show static deadlock
    st.subheader("📍 Static Deadlock Check")
    st.markdown(explain_static_deadlock(scenario))

    if mode == "Deadlock Detection":
        st.subheader("🔁 Live Deadlock Prediction")
        cycle = predict_deadlock_from_live_state(simulator)
        st.markdown(explain_live_deadlock(cycle))

    if mode == "Race Condition Detection":
        st.subheader("⚡ Race Condition Detection")
        races = check_race_conditions(st.session_state.timeline)
        if races:
            st.warning("⚠️ Race condition on lock(s): " + ", ".join(races))
        else:
            st.success("✅ No race conditions detected.")
