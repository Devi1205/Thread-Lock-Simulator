from backend.models import Thread, Lock, Event

class ThreadSimulator:
    def __init__(self):
        self.threads = []
        self.locks = {}
        self.timeline = []

    def load_scenario(self, scenario):
        self.threads = []
        self.locks = {name: Lock(name) for name in scenario["locks"]}
        for t in scenario["threads"]:
            self.threads.append(Thread(t["name"], t["instructions"]))
        self.timeline = []

    def reset(self):
        for lock in self.locks.values():
            lock.held_by = None
        for thread in self.threads:
            thread.pointer = 0
        self.timeline = []

    def has_more_steps(self):
        return any(t.pointer < len(t.instructions) for t in self.threads)

    def step(self):
        progress_made = False

        for thread in self.threads:
            if thread.pointer >= len(thread.instructions):
                continue

            action, name = thread.instructions[thread.pointer]
            lock = self.locks.get(name)

            if action == 'acquire':
                if lock and lock.held_by is None:
                    lock.held_by = thread.name
                    self.timeline.append(Event(thread.name, 'acquire', lock.name))
                    thread.pointer += 1
                    progress_made = True
                else:
                    held_by = lock.held_by if lock else None
                    # Avoid duplicate blocked entries at the simulator level
                    last_event = self.timeline[-1] if self.timeline else None
                    if not (last_event and last_event.thread == thread.name and
                            last_event.action == 'blocked' and last_event.lock == name and
                            last_event.held_by == held_by):
                        self.timeline.append(Event(thread.name, 'blocked', name, held_by=held_by))
                    # pointer NOT advanced

            elif action == 'release':
                if lock and lock.held_by == thread.name:
                    lock.held_by = None
                    self.timeline.append(Event(thread.name, 'release', lock.name))
                    thread.pointer += 1
                    progress_made = True

            elif action == 'access':
                self.timeline.append(Event(thread.name, 'access', name))
                thread.pointer += 1
                progress_made = True

        return progress_made

# Export singleton
simulator = ThreadSimulator()
