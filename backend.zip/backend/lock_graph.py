import networkx as nx

def build_lock_graph(events):
    graph = nx.DiGraph()
    held_by = {}  # lock_name → thread_name

    for event in events:
        if event.action == 'acquire':
            held_by[event.lock] = event.thread

        elif event.action == 'release':
            held_by.pop(event.lock, None)

        elif event.action == 'blocked':
            lock_holder = getattr(event, "held_by", None)
            if lock_holder:
                graph.add_edge(event.thread, lock_holder)

    return graph

def detect_deadlock(graph):
    try:
        return nx.find_cycle(graph, orientation='original')
    except nx.NetworkXNoCycle:
        return None
