# backend/utils.py

import os

def create_required_folders():
    folders = [
        "assets/examples",
        "assets/icons",
        "data/graphs",
        "data/execution_logs",
        "docs/screenshots"
    ]
    for folder in folders:
        os.makedirs(folder, exist_ok=True)
