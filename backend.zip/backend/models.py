class Thread:
    def __init__(self, name, instructions):
        self.name = name
        self.instructions = instructions  # List of ['acquire', 'L1'], etc.
        self.pointer = 0  # Tracks which instruction is next


class Lock:
    def __init__(self, name):
        self.name = name
        self.held_by = None  # Name of thread currently holding the lock
        

class Event:
    def __init__(self, thread, action, lock, held_by=None):
        self.thread = thread          # Thread name performing the action
        self.action = action          # 'acquire', 'release', or 'blocked'
        self.lock = lock              # Lock name
        self.held_by = held_by        # ✅ Only set when action is 'blocked'
