
# === backend/static_analyzer.py ===
def static_deadlock_check(scenario):
    dependencies = {}
    for thread in scenario['threads']:
        held = set()
        for action, lock in thread['instructions']:
            if action == 'acquire':
                for h in held:
                    dependencies.setdefault(h, set()).add(lock)
                held.add(lock)
            elif action == 'release':
                held.discard(lock)

    visited = set()
    def visit(lock, path):
        if lock in path:
            return True
        path.add(lock)
        for dep in dependencies.get(lock, []):
            if visit(dep, path.copy()):
                return True
        return False

    for lock in dependencies:
        if visit(lock, set()):
            return True
    return False