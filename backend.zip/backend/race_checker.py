# === backend/race_checker.py ===
from collections import defaultdict

def check_race_conditions(events):
    """
    Detects race conditions from access events by checking if two threads
    access the same variable without holding any common locks.
    """

    # Step 1: Track locks held by each thread at each access
    held_locks = defaultdict(set)
    access_history = defaultdict(list)  # var → [(thread, i, held_locks)]

    for i, event in enumerate(events):
        if event.action == "acquire":
            held_locks[event.thread].add(event.lock)
        elif event.action == "release":
            held_locks[event.thread].discard(event.lock)
        elif event.action == "access":
            access_history[event.lock].append((event.thread, i, held_locks[event.thread].copy()))

    # Step 2: Compare access records to find race conditions
    race_vars = set()

    for var, accesses in access_history.items():
        for i in range(len(accesses)):
            t1, idx1, locks1 = accesses[i]
            for j in range(i + 1, len(accesses)):
                t2, idx2, locks2 = accesses[j]

                if t1 != t2 and locks1.isdisjoint(locks2):
                    race_vars.add(var)

    return list(race_vars)
