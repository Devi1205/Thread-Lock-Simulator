# === backend/deadlock_predictor.py ===
import networkx as nx
from backend.lock_graph import detect_deadlock

def predict_deadlock_from_live_state(simulator):
    graph = build_wait_for_graph(simulator)
    return detect_deadlock(graph)

def build_wait_for_graph(simulator):
    import networkx as nx
    graph = nx.DiGraph()

    for event in simulator.timeline:
        if event.action == "blocked" and event.held_by:
            # Thread is waiting on lock held by another thread
            graph.add_edge(event.thread, event.held_by)

    return graph
